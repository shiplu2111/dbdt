<div style="height: 120px; width: 120px">
    <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(URL::to('front/assets/images/logo.svg')); ?>"></a>
</div>
<?php /**PATH /home/timetech/dev.timetech.one/resources/views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>
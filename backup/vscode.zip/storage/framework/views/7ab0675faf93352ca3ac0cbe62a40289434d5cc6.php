<!DOCTYPE html>
<html>

<head>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">



    <link rel="stylesheet" href="<?php echo e(URL::to('front/assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::to('front/assets/css/bootstrap-select.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('front/assets/fonts/font-awesome/font-awesome.css')); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('front/assets/css/animate.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('front/assets/slick.slider/slick-theme.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('front/assets/slick.slider/slick.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('front/assets/fonts/custom-fonts.css')); ?>">
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Quicksand:wght@300;400;500;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('front/style.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('front/assets/css/responsive.css')); ?>">

    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</head>

<body>
    <div id="app">
        <header class="header">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="header-inr clearfix">
                            <div class="hdr-lft clearfix">
                                <div class="logo">
                                    <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(URL::to('front/assets/images/logo.svg')); ?>"></a>
                                </div>
                                <h1>DBDT<span>Future digital asset</span></h1>
                            </div>
                            <div class="hdr-rgt">
                                <div class="xs-hambergar show-md">
                                    <div class="hambergar-icon">
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                    </div>
                                </div>
                                <nav class="main-nav">
                                    <ul class="clearfix reset-list">
                                        <li class="current-menu-item">
                                            <a href="<?php echo e(url('/')); ?>">Home</a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(url('/buy-dbdt')); ?>">
                                                BUY DBDT
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(url('/stake-dbdt')); ?>">
                                                STAKE DBDT
                                            </a>
                                        </li>
                                        


                                        <li><a href="https://bscscan.com/address/0x02210ccf0ed27a26977e85528312e5bd53ce9960"
                                                target="_blank">EXPLORER</a></li>
                                        <li>
                                            <a href="<?php echo e(url('/mastercard')); ?>">MASTERCARD</a>
                                        </li>

                                        <li class="menu-item-has-children">
                                            <a href="#"><i class="far fa-user"></i></a>
                                            <ul class="sub-menu reset-list">
                                                <?php if(auth()->guard()->guest()): ?>
                                                <?php if(Route::has('register')): ?>
                                                <li>
                                                    <a href="<?php echo e(url('/login')); ?>">Login</a>
                                                </li>
                                                <li>
                                                    <a href="<?php echo e(url('/register')); ?>">Register</a>
                                                </li>
                                                <?php endif; ?>
                                                <?php else: ?>
                                                <li>
                                                    <a href="<?php echo e(url('/login')); ?>">
                                                        Dashboard
                                                    </a>
                                                </li>
                                                <?php endif; ?>

                                            </ul>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
<?php /**PATH /home/timetech/dev.timetech.one/resources/views/frontend/layouts/header.blade.php ENDPATH**/ ?>
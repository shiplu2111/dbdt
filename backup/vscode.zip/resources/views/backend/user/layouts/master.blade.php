@include('backend.user.layouts.header')
@include('backend.user.layouts.sidebar')
@yield('content')
@include('backend.user.layouts.footer')
